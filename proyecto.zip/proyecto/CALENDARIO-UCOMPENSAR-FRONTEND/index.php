<html>
  <head>
    <title>EVENTOS UCOMPENSAR</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../../public/css/estructura.css">

  </head>
  <body>
  <!-- CARRUSEL PANTALLA PRINCIPAL -->
  <div class="carrusel">
    <div class="carrusel-items">
      <div class="carrusel-item">
        <img src="/public/img/bosque.jpg" alt="">
      </div>
      <div class="carrusel-item">
        <img src="/public/img/evento.jpg" alt="">
      </div>
      <div class="carrusel-item">
        <img src="/public/img/graduaciones.jpg" alt="">
      </div>
      <div class="carrusel-item">
        <img src="/public/img/ucompensar.jpg" alt="">
      </div>
    </div>
  </div>
  
<!-- MENU -->
<?php include('src/Components/menu.php'); ?>
<!-- FIN MENU -->




  <!-- IMAGEN CENTRAL -->
  <div class="row central">
      <div class="col-md-12 central-tip">
          <h1>EVENTOS UCOMPENSAR</h1>
          <p>
              Descubre todas las actividades, talleres y eventos especiales que tenemos para ti. 
              Desde capacitaciones, charlas de bienestar, actividades culturales y deportivas, hasta encuentros comunitarios, 
              nuestro calendario te permite estar al día y participar en todo lo que UCompensar ofrece.
          </p>
          <a class="click-btn btn-style700" href="Calendario/calendario.html">Ver Calendario</a>
      </div>
  </div>

  <div class="row final">
    <div class="col-md-12"></div>
  </div>

    </body>
  </html>

