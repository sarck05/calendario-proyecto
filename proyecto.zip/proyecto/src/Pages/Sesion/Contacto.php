<?php
session_start(); // Para manejar el menú dinámico según sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contáctanos - UCompensar</title>

  <!-- Librerías externas -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- Estilos personalizados -->
  <link rel="stylesheet" href="/public/css/estructura.css">
  <style>
    body {
      background-color: #f5f8fa;
      padding-top: 90px; /* espacio para menú fijo */
    }
    .form-container {
      max-width: 600px;
      margin: 60px auto;
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    .form-container h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }
    .btn-enviar {
      background-color: #f47c20;
      color: white;
      border: none;
    }
    .btn-enviar:hover {
      background-color: #d8661a;
    }
    .draft-hint {
      display: none;
      font-size: 12px;
      color: #2d6a4f;
      margin-top: 8px;
    }
    .draft-hint.show { display:block; }
  </style>
</head>
<body>

  <!-- MENU -->
  <?php include(__DIR__ . '/../../Components/menu.php'); ?>
  <!-- FIN MENU -->

  <div class="form-container">
    <h2><i class="bi bi-chat-dots-fill"></i> Contáctanos</h2>
    <form action="https://formspree.io/f/manpdklb" method="POST" id="contactForm">
      <div class="form-group">
        <label for="nombre"><i class="bi bi-person-fill"></i> Nombre completo</label>
        <input type="text" class="form-control" name="name" id="nombre" required placeholder="Tu nombre">
      </div>
      <div class="form-group">
        <label for="email"><i class="bi bi-envelope-fill"></i> Correo electrónico</label>
        <input type="email" class="form-control" name="email" id="email" required placeholder="ejemplo@correo.com">
      </div>
      <div class="form-group">
        <label for="asunto"><i class="bi bi-pencil-fill"></i> Asunto</label>
        <input type="text" class="form-control" name="subject" id="asunto" required placeholder="¿Sobre qué quieres hablar?">
      </div>
      <div class="form-group">
        <label for="mensaje"><i class="bi bi-chat-left-text-fill"></i> Mensaje</label>
        <textarea class="form-control" name="message" id="mensaje" rows="5" required placeholder="Escribe tu mensaje aquí..."></textarea>
      </div>
      <button type="submit" class="btn btn-enviar btn-block">Enviar mensaje</button>
      <div id="draftHint" class="draft-hint"><i class="bi bi-save2"></i> Borrador guardado en este navegador.</div>
    </form>
  </div>

  <script>
    // ========= Local Storage robusto =========
    (function() {
      const STORAGE_KEY = 'ucomp_contacto_borrador_v1';

      function storageAvailable() {
        try {
          const x = '__storage_test__' + Math.random();
          localStorage.setItem(x, x);
          const ok = localStorage.getItem(x) === x;
          localStorage.removeItem(x);
          return ok;
        } catch (e) {
          console.warn('localStorage NO disponible:', e && e.message ? e.message : e);
          return false;
        }
      }

      const canStore = storageAvailable();
      const $form   = $('#contactForm');
      const $nombre = $('#nombre');
      const $email  = $('#email');
      const $asunto = $('#asunto');
      const $mensaje= $('#mensaje');
      const $hint   = $('#draftHint');

      function showHint(ms = 1500) {
        if (!$hint.length) return;
        $hint.addClass('show');
        setTimeout(() => $hint.removeClass('show'), ms);
      }

      function loadDraft() {
        if (!canStore) return;
        try {
          const raw = localStorage.getItem(STORAGE_KEY);
          if (!raw) { console.log('No hay borrador en storage'); return; }
          const data = JSON.parse(raw);
          if (data && typeof data === 'object') {
            if (data.name)    $nombre.val(data.name);
            if (data.email)   $email.val(data.email);
            if (data.subject) $asunto.val(data.subject);
            if (data.message) $mensaje.val(data.message);
            console.log('Borrador restaurado desde localStorage:', data);
            showHint(2500);
          }
        } catch (e) {
          console.warn('Error restaurando borrador:', e);
        }
      }

      let saveTimer = null;
      function scheduleSave() {
        if (!canStore) return;
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(saveDraft, 300); // debounce 300ms
      }

      function saveDraft() {
        if (!canStore) return;
        try {
          const data = {
            name:    $nombre.val()  || '',
            email:   $email.val()   || '',
            subject: $asunto.val()  || '',
            message: $mensaje.val() || '',
            ts: Date.now()
          };
          localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
          console.log('Borrador guardado en localStorage:', data);
          showHint();
        } catch (e) {
          console.warn('Error guardando borrador:', e);
        }
      }

      function clearDraft() {
        if (!canStore) return;
        try {
          localStorage.removeItem(STORAGE_KEY);
          console.log('Borrador eliminado de localStorage');
        } catch (e) {
          console.warn('No se pudo borrar el borrador:', e);
        }
      }

      // Bind de eventos (después de que el DOM ya tiene los campos)
      $nombre.on('input change', scheduleSave);
      $email.on('input change', scheduleSave);
      $asunto.on('input change', scheduleSave);
      $mensaje.on('input change', scheduleSave);

      // Cargar borrador al cargar DOM
      $(function() { loadDraft(); });

      // Tu envío AJAX existente + limpieza de borrador en éxito
      $form.on('submit', function(e) {
        e.preventDefault();
        $.ajax({
          url: $(this).attr('action'),
          method: 'POST',
          data: $(this).serialize(),
          dataType: 'json',
          success: function(resp) {
            clearDraft();
            Swal.fire({
              icon: 'success',
              title: '¡Mensaje enviado!',
              text: 'Gracias por contactarnos. Te responderemos pronto.',
              confirmButtonColor: '#f47c20'
            });
            $form[0].reset();
          },
          error: function(xhr) {
            // Conservamos borrador en error para que no se pierda
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Hubo un problema al enviar tu mensaje. Intenta nuevamente.',
              confirmButtonColor: '#f47c20'
            });
          }
        });
      });

      // Limpia borrador si todo quedó vacío al salir
      window.addEventListener('beforeunload', function() {
        const isEmpty =
          (!$nombre.val()  || !$nombre.val().trim()) &&
          (!$email.val()   || !$email.val().trim()) &&
          (!$asunto.val()  || !$asunto.val().trim()) &&
          (!$mensaje.val() || !$mensaje.val().trim());
        if (isEmpty) clearDraft();
      });
    })();
  </script>

</body>
</html>
