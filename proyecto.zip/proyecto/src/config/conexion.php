<?php
// src/config/conexion.php
// Soluciona "Unknown database 'gestioneventos'": crea la BD y la tabla si no existen.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = "localhost";      // XAMPP: normalmente localhost
$user = "root";           // XAMPP: root
$pass = "";               // XAMPP: contraseña vacía
$db   = "gestioneventos"; // nombre de tu base de datos

try {
    // 1) Intentar conectar directamente a la BD
    $conn = new mysqli($host, $user, $pass, $db);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    // 1049 = Unknown database
    if ($e->getCode() === 1049 || stripos($e->getMessage(), 'Unknown database') !== false) {
        // 2) Conectar sin seleccionar BD
        $conn = new mysqli($host, $user, $pass);
        $conn->set_charset('utf8mb4');

        // 3) Crear la BD y seleccionarla
        $conn->query("CREATE DATABASE IF NOT EXISTS `$db`
                      CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->select_db($db);

        // 4) Asegurar la tabla 'eventos' (la que usas en tu SELECT)
        $conn->query("
            CREATE TABLE IF NOT EXISTS `eventos` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `nombre` VARCHAR(150) NOT NULL,
              `descripcion` TEXT NULL,
              `tipo` VARCHAR(50) NULL,
              `fecha` DATETIME NOT NULL,
              `creado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB
              DEFAULT CHARSET=utf8mb4
              COLLATE=utf8mb4_unicode_ci
        ");

        // (Opcional) Semillas de ejemplo para ver algo en el calendario:
        // $conn->query(\"INSERT INTO eventos (nombre, descripcion, tipo, fecha)
        //               VALUES ('Evento Demo', 'Prueba de calendario', 'demo', NOW() + INTERVAL 1 DAY)\");
    } else {
        // Otros errores de conexión: relanza
        throw $e;
    }
}
