<?php
include("../../config/conexion.php");

// Reiniciar contraseñas de prueba
$usuarios = [
    ['correo' => 'carlos.profesor@ucompensar.edu.co', 'clave' => '12345'],
    ['correo' => 'pepepro@correo.com', 'clave' => '12345'],
    ['correo' => 'laura@correo.com', 'clave' => '12345'],
    ['correo' => 'admin@correo.com', 'clave' => 'admin123']
];

foreach ($usuarios as $u) {
    $hash = password_hash($u['clave'], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE usuarios SET clave=? WHERE correo=?");
    $stmt->bind_param("ss", $hash, $u['correo']);
    $stmt->execute();
}

echo "Contraseñas restauradas correctamente.";
?>

