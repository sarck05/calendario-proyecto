<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Variables de sesión ---
$logeado = isset($_SESSION['usuario_id']);
$nombre = $logeado ? $_SESSION['usuario_nombre'] : '';
$rol = $logeado ? $_SESSION['usuario_rol'] : '';

// --- Conexión y consulta ---
include(__DIR__ . '/../../config/conexion.php');

$sql = "SELECT id, titulo, contenido, imagen, fecha, es_urgente
        FROM noticias
        ORDER BY fecha DESC";
$result = $conn->query($sql);

$news_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $news_data[] = [
            'id' => (int)$row['id'],
            'titulo' => htmlspecialchars($row['titulo']),
            'contenido' => htmlspecialchars($row['contenido']),
            'imagen' => $row['imagen']
                ? '../../../public/uploads/' . htmlspecialchars($row['imagen'])
                : "https://picsum.photos/seed/noticia{$row['id']}/600/400.jpg",
            'fecha' => date('d/m/Y H:i', strtotime($row['fecha'])),
            'es_urgente' => (bool)$row['es_urgente']
        ];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Noticias UCompensar</title>

    <!-- CSS del menú -->
    <link rel="stylesheet" href="/public/css/estructura.css">

    <!-- Librerías externas -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Estilos personalizados -->
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f5f6fa;
        }

        .news-container {
            max-width: 700px;
            margin: 0 auto;
            padding-top: 20px;
        }

        .news-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            overflow: hidden;
            transition: transform 0.2s ease-in-out;
        }

        .news-card:hover {
            transform: translateY(-3px);
        }

        .news-urgent {
            background-color: #c62828;
            color: white;
            font-weight: bold;
            padding: 6px 10px;
            font-size: 14px;
            text-transform: uppercase;
        }

        .news-header {
            padding: 15px;
        }

        .news-title {
            font-size: 20px;
            font-weight: 600;
            margin: 0 0 8px;
            color: #333;
        }

        .news-date {
            color: #888;
            font-size: 13px;
        }

        .news-image {
            width: 100%;
            height: auto;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }

        .news-content {
            padding: 15px;
            font-size: 15px;
            color: #555;
        }

        .no-news {
            text-align: center;
            margin-top: 50px;
            font-size: 18px;
            color: #888;
        }
    </style>
</head>
<body>

<!-- 🔹 MENÚ PRINCIPAL (mismo que el del resto del sistema) -->
<div class="Menu">
  <div class="container-fluid menu-container">
    <div class="row menu-row">
      <!-- LOGO -->
      <div class="col-md-3 menu-logo">
        <img src="/public/img/logo-compensar.png" alt="Logo Compensar" class="img-responsive">
      </div>

      <!-- MENÚ PRINCIPAL -->
      <div class="col-md-6">
        <ul class="nav navbar-nav menu-principal">
          <li><a href="/index.php">Inicio</a></li>
          <li><a href="/src/Pages/Calendario/calendario.php">Calendario</a></li>
          <li><a href="/src/Pages/Eventos/eventos.php">Eventos</a></li>
          <li class="active"><a href="/src/Pages/Noticias/noticias.php">Noticias</a></li>
          <li><a href="/src/Pages/Sesion/Contacto.php">Contáctanos</a></li>
        </ul>
      </div>

      <!-- SESIÓN DE USUARIO -->
      <div class="col-md-3" style="margin-right: 20px;">
        <ul class="nav navbar-nav navbar-right menu-sesion">
          <?php if (!$logeado): ?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="bi bi-person-fill-down"></i> Iniciar Sesión <span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <li><a href="/src/Pages/Sesion/login.php"><i class="bi bi-person-fill"></i> Login</a></li>
                <li><a href="/src/Pages/Sesion/register.php"><i class="bi bi-person-fill-add"></i> Registrarse</a></li>
              </ul>
            </li>
          <?php else: ?>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="bi bi-person-fill"></i> <?= htmlspecialchars($nombre) ?> <span class="caret"></span>
              </a>
              <ul class="dropdown-menu">
                <?php if ($rol === 'admin'): ?>
                  <li><a href="/src/Pages/Panel/panel.php"><i class="bi bi-speedometer2"></i> Panel Central</a></li>
                <?php endif; ?>
                <li><a href="/src/Pages/Sesion/perfil.php"><i class="bi bi-person"></i> Perfil</a></li>
                <li><a href="/src/Pages/Sesion/logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a></li>
              </ul>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- 🔹 CONTENIDO DE NOTICIAS -->
<div class="container news-container">
  <h2 class="text-center mb-4"><strong>Últimas Noticias</strong></h2>

  <?php if (empty($news_data)): ?>
    <div class="no-news">
      <p>No hay noticias disponibles en este momento.</p>
    </div>
  <?php else: ?>
    <?php foreach ($news_data as $news): ?>
      <div class="news-card">
        <?php if ($news['es_urgente']): ?>
          <div class="news-urgent">URGENTE</div>
        <?php endif; ?>

        <div class="news-header">
          <h3 class="news-title"><?= $news['titulo']; ?></h3>
          <span class="news-date">
            <i class="glyphicon glyphicon-time"></i> <?= $news['fecha']; ?>
          </span>
        </div>

        <img src="<?= $news['imagen']; ?>" class="news-image" alt="Imagen de noticia">

        <div class="news-content">
          <p><?= nl2br($news['contenido']); ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

</body>
</html>
