<?php
// Asegúrate de que esta sea la PRIMERA línea de código PHP en el archivo.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once(__DIR__ . '/../../config/conexion.php');
// ... resto del código
require_once(__DIR__ . '/../../config/conexion.php');

header('Content-Type: application/json');

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Usuario no logueado.']);
    exit();
}

// Verificar si se recibieron los datos por POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['evento_id']) || !isset($_POST['action'])) {
    echo json_encode(['status' => 'error', 'message' => 'Petición no válida.']);
    exit();
}

 $usuario_id = $_SESSION['usuario_id'];
 $evento_id = intval($_POST['evento_id']);
 $action = $_POST['action']; // 'add' o 'remove'

if ($evento_id <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'ID de evento no válido.']);
    exit();
}

try {
    if ($action === 'add') {
        // Verificar si ya existe para evitar duplicados
        $sql_check = "SELECT id FROM favoritos WHERE id_usuario = ? AND id_evento = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("ii", $usuario_id, $evento_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            echo json_encode(['status' => 'exists', 'message' => 'El evento ya está en tus favoritos.']);
            exit();
        }

        // Añadir a favoritos
        $sql_insert = "INSERT INTO favoritos (id_usuario, id_evento) VALUES (?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("ii", $usuario_id, $evento_id);
        
        if ($stmt_insert->execute()) {
            echo json_encode(['status' => 'ok', 'message' => '✅ Evento añadido a favoritos.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => '❌ Error al añadir a favoritos.']);
        }

    } elseif ($action === 'remove') {
        // Quitar de favoritos
        $sql_delete = "DELETE FROM favoritos WHERE id_usuario = ? AND id_evento = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("ii", $usuario_id, $evento_id);

        if ($stmt_delete->execute()) {
            echo json_encode(['status' => 'ok', 'message' => '❌ Evento eliminado de favoritos.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => '❌ Error al eliminar de favoritos.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Acción no reconocida.']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error en el servidor: ' . $e->getMessage()]);
}

 $conn->close();
?>