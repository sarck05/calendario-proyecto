<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/../../config/conexion.php');

// --- OBTENER FAVORITOS DEL USUARIO ---
 $user_favorites_ids = [];
if (isset($_SESSION['usuario_id'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $sql_fav = "SELECT id_evento FROM favoritos WHERE id_usuario = ?";
    $stmt_fav = $conn->prepare($sql_fav);
    $stmt_fav->bind_param("i", $usuario_id);
    $stmt_fav->execute();
    $result_fav = $stmt_fav->get_result();
    while ($row = $result_fav->fetch_assoc()) {
        $user_favorites_ids[] = $row['id_evento'];
    }
}

// --- OBTENER TODOS LOS EVENTOS ---
 $sql = "SELECT
            e.id, e.nombre, e.descripcion, e.tipo, e.fecha, e.imagen,
            GROUP_CONCAT(et.nombre SEPARATOR ', ') AS etiquetas
        FROM eventos e
        LEFT JOIN evento_etiquetas ee ON e.id = ee.evento_id
        LEFT JOIN etiquetas et ON ee.etiqueta_id = et.id
        GROUP BY e.id
        ORDER BY e.fecha ASC";
 $result = $conn->query($sql);

 $events_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $timestamp = strtotime($row['fecha']);
        $events_data[] = [
            'id' => (int)$row['id'],
            'title' => $row['nombre'],
            'description' => $row['descripcion'],
            'event_date' => date('Y-m-d', $timestamp),
            'event_time' => date('H:i', $timestamp),
            'category' => $row['tipo'],
            'etiquetas' => $row['etiquetas'] ?: 'Sin etiquetas',
            'image' => $row['imagen']
                ? '../../../public/uploads/' . htmlspecialchars($row['imagen'])
                : "https://picsum.photos/seed/evento{$row['id']}/600/400.jpg",
        ];
    }
}

 $conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos UCompensar</title>
    
    <!-- Fuentes y librerías -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../../../public/css/eventos.css">

    <style>
        .event-card { 
            position: relative; 
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        /* Estilo mejorado para el botón de favoritos */
        .favorite-container {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 10;
        }
        
        .favorite-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.85);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .favorite-btn:hover {
            background-color: #fff;
            transform: scale(1.1);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }
        
        .favorite-btn i {
            font-size: 20px;
            color: #e74c3c;
            transition: all 0.3s ease;
        }
        
        .favorite-btn:not(.is-favorite) i {
            color: #aaa;
        }
        
        .favorite-btn.is-favorite i {
            color: #e74c3c;
            animation: heartBeat 0.6s ease;
        }
        
        @keyframes heartBeat {
            0% { transform: scale(1); }
            25% { transform: scale(1.3); }
            50% { transform: scale(1); }
            75% { transform: scale(1.3); }
            100% { transform: scale(1); }
        }
        
        .row:before, .row:after {
            display: none !important;
            content: none !important;
        }
        
        .event-image {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
    </style>
</head>
<body class="Eventos">
    <?php include('../../Components/menu.php'); ?>

    <?php if (isset($_SESSION['usuario_id'])): ?>
        <input type="hidden" id="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">
    <?php else: ?>
        <input type="hidden" id="usuario_id" value="">
    <?php endif; ?>

    <div class="container mt-5">
        <div class="header text-center mb-4">
            <h1>EVENTOS UCOMPENSAR</h1>
            <p>Descubre los próximos eventos en nuestra universidad</p>
        </div>

        <?php if (empty($events_data)): ?>
            <div class="alert alert-warning text-center">
                <h4>No hay eventos disponibles en este momento.</h4>
                <p>Vuelve pronto para conocer nuestras nuevas actividades.</p>
            </div>
        <?php else: ?>
            <div class="row" id="listaEventos">
                <?php foreach ($events_data as $ev): ?>
                    <?php
                        $is_favorite = in_array($ev['id'], $user_favorites_ids);
                        $btn_class = $is_favorite ? 'is-favorite' : '';
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="event-card shadow-sm">
                            <div class="favorite-container">
                                <button class="favorite-btn <?php echo $btn_class; ?>"
                                        data-event-id="<?php echo $ev['id']; ?>"
                                        title="<?php echo $is_favorite ? 'Quitar de favoritos' : 'Añadir a favoritos'; ?>">
                                    <i class="bi bi-heart-fill"></i>
                                </button>
                            </div>
                            <img src="<?php echo $ev['image']; ?>" class="event-image" alt="<?php echo $ev['title']; ?>">
                            <div class="event-body">
                                <div class="event-category"><?php echo htmlspecialchars($ev['category']); ?></div>
                                <h5 class="event-title"><?php echo htmlspecialchars($ev['title']); ?></h5>
                                <p class="event-description"><?php echo htmlspecialchars($ev['description']); ?></p>
                                <div class="event-meta">
                                    <span><i class="bi bi-calendar-event"></i> <?php echo $ev['event_date']; ?></span>
                                    <span><i class="bi bi-clock"></i> <?php echo $ev['event_time']; ?></span>
                                </div>
                                <button class="btn btn-primary details-btn w-100" data-event-id="<?php echo $ev['id']; ?>">Ver Detalles</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- MODAL -->
    <div class="modal fade" id="eventDetailsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Título del Evento</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <img id="modalImage" src="" class="img-fluid rounded shadow-sm" alt="Imagen del evento">
                        </div>
                        <div class="col-md-7">
                            <p id="modalDescription">Descripción...</p>
                            <div class="modal-meta">
                                <p><i class="bi bi-calendar-event"></i> <strong>Fecha:</strong> <span id="modalDate">--</span></p>
                                <p><i class="bi bi-clock"></i> <strong>Hora:</strong> <span id="modalTime">--</span></p>
                                <p><i class="bi bi-tag"></i> <strong>Categoría:</strong> <span id="modalCategory">--</span></p>
                                <p><i class="bi bi-tags"></i> <strong>Etiquetas:</strong> <span id="modalTags">--</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="detalleIdEvento" name="detalleIdEvento" value="">
                <div class="modal-footer d-flex justify-content-between">
                    <button id="btnInscribirse" class="btn btn-primary">Inscribirse</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script id="events-data" type="application/json"><?php echo json_encode($events_data, JSON_UNESCAPED_UNICODE); ?></script>

    <script>
    $(document).ready(function () {
        // --- FAVORITOS ---
        $('.favorite-btn').on('click', function (e) {
            e.stopPropagation();
            const btn = $(this);
            const usuarioId = $('#usuario_id').val();
            const eventoId = btn.data('event-id');

            if (!usuarioId) return alert('⚠️ Debes iniciar sesión para usar favoritos.');

            const isFav = btn.hasClass('is-favorite');
            const action = isFav ? 'remove' : 'add';
            btn.toggleClass('is-favorite');

            $.post('toggle_favorito.php', {
                usuario_id: usuarioId,
                evento_id: eventoId,
                action: action
            }, function (response) {
                if (response.status !== 'ok') {
                    btn.toggleClass('is-favorite');
                    alert(response.message || 'Error al cambiar favorito.');
                } else {
                    btn.attr('title', action === 'add' ? 'Quitar de favoritos' : 'Añadir a favoritos');
                }
            }, 'json').fail(function () {
                btn.toggleClass('is-favorite');
                alert('❌ Error al conectar con el servidor.');
            });
        });

        // --- MODAL DETALLES ---
        const events = JSON.parse($('#events-data').text());
        $('.details-btn').on('click', function () {
            const event = events.find(e => e.id === parseInt($(this).data('event-id')));
            if (!event) return alert('No se encontró la información del evento.');

            $('#modalTitle').text(event.title);
            $('#modalImage').attr('src', event.image);
            $('#modalDescription').text(event.description);
            $('#modalDate').text(event.event_date);
            $('#modalTime').text(event.event_time);
            $('#modalCategory').text(event.category);
            $('#modalTags').text(event.etiquetas);
            $('#detalleIdEvento').val(event.id);
            $('#eventDetailsModal').modal('show');
        });

        // --- INSCRIPCIÓN ---
        $('#btnInscribirse').on('click', function () {
            const usuarioId = $('#usuario_id').val();
            const eventoId = $('#detalleIdEvento').val();

            if (!usuarioId) return alert('⚠️ Inicia sesión para inscribirte.');
            if (!eventoId) return alert('⚠️ No se pudo identificar el evento.');

            $.post('inscribirse_evento.php', {
                usuario_id: usuarioId,
                evento_id: eventoId
            }, function (data) {
                if (data.status === 'ok') {
                    alert('✅ Te has inscrito correctamente.');
                    $('#eventDetailsModal').modal('hide');
                } else if (data.status === 'exists') {
                    alert('⚠️ Ya estás inscrito.');
                } else {
                    alert('❌ Error al inscribirte.');
                }
            }, 'json').fail(() => alert('❌ No se pudo conectar con el servidor.'));
        });
    });
    </script>
</body>
</html>