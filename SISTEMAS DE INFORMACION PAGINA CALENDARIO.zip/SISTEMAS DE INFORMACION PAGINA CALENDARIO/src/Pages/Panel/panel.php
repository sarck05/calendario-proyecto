<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- CONEXIÓN BD ---
$conn = new mysqli('localhost', 'root', '', 'gestioneventos');
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// --- INSERTAR EVENTO ---
if (isset($_POST['crear_evento'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $lugar = $_POST['lugar'];

    // Manejar subida de imagen
    $imagen = null;
    if (!empty($_FILES['imagen']['name'])) {
        $directorio = __DIR__ . '/../Eventos/imagenesEventos/';
        if (!is_dir($directorio)) mkdir($directorio, 0777, true);

        $nombreArchivo = time() . '_' . basename($_FILES['imagen']['name']);
        $rutaDestino = $directorio . $nombreArchivo;

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            $imagen = '/src/Pages/Eventos/imagenesEventos/' . $nombreArchivo;
        }
    }

    $sql = "INSERT INTO eventos (nombre, descripcion, fecha, hora, lugar, imagen) 
            VALUES ('$nombre', '$descripcion', '$fecha', '$hora', '$lugar', '$imagen')";
    $conn->query($sql);
}

// --- INSERTAR NOTICIA ---
if (isset($_POST['crear_noticia'])) {
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $es_urgente = isset($_POST['es_urgente']) ? 1 : 0;

    // Manejar subida de imagen
    $imagen = null;
    if (!empty($_FILES['imagen']['name'])) {
        $directorio = __DIR__ . '/../Noticias/imagenesNoticias/';
        if (!is_dir($directorio)) mkdir($directorio, 0777, true);

        $nombreArchivo = time() . '_' . basename($_FILES['imagen']['name']);
        $rutaDestino = $directorio . $nombreArchivo;

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            $imagen = '/src/Pages/Noticias/imagenesNoticias/' . $nombreArchivo;
        }
    }

    $sql = "INSERT INTO noticias (titulo, contenido, imagen, es_urgente) 
            VALUES ('$titulo', '$contenido', '$imagen', $es_urgente)";
    $conn->query($sql);
}

// --- CONSULTAS PARA VISUALIZAR ---
$eventos = $conn->query("SELECT * FROM eventos ORDER BY fecha DESC");
$noticias = $conn->query("SELECT * FROM noticias ORDER BY fecha DESC");
?>

<!-- MENÚ PRINCIPAL -->
<?php include($_SERVER['DOCUMENT_ROOT'] . '/src/Components/menu.php'); ?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración</title>
  <link rel="stylesheet" href="/public/css/panel.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .panel-container {
      margin: 50px auto;
      width: 80%;
      color: white;
    }
    .form-box {
      background-color: #1a1a1a;
      border-radius: 15px;
      padding: 30px;
      margin-bottom: 40px;
      box-shadow: 0 0 10px rgba(255,255,255,0.1);
    }
    .form-box h3 {
      margin-bottom: 20px;
      text-align: center;
    }
    .visualizar-box {
      background-color: #222;
      padding: 15px;
      border-radius: 10px;
      margin-top: 20px;
      display: none;
    }
    .btn-visualizar {
      margin-left: 10px;
    }
  </style>
</head>

<body style="background-color: #0e0e0e; color: white;">

<div class="panel-container">

  <!-- FORMULARIO CREAR EVENTO -->
  <div class="form-box">
    <h3>Crear Evento</h3>
    <form method="POST" action="panel.php" enctype="multipart/form-data">
      <div class="form-group">
        <label>Nombre del evento</label>
        <input type="text" name="nombre" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control" required></textarea>
      </div>
      <div class="form-group">
        <label>Fecha</label>
        <input type="date" name="fecha" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Hora</label>
        <input type="time" name="hora" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Lugar</label>
        <input type="text" name="lugar" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Subir Imagen</label>
        <input type="file" name="imagen" class="form-control">
      </div>
      <button type="submit" name="crear_evento" class="btn btn-success">Crear Evento</button>
      <button type="button" class="btn btn-info btn-visualizar" id="btnVerEventos">Visualizar Eventos</button>
    </form>

    <div class="visualizar-box" id="listaEventos">
      <h4>Lista de Eventos</h4>
      <ul>
        <?php while ($e = $eventos->fetch_assoc()): ?>
          <li>
            <?= htmlspecialchars($e['nombre']) ?> - <?= htmlspecialchars($e['fecha']) ?>
            <?php if (!empty($e['imagen'])): ?>
              <br><img src="<?= $e['imagen'] ?>" width="120" style="margin-top:5px;border-radius:8px;">
            <?php endif; ?>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>

  <!-- FORMULARIO CREAR NOTICIA -->
  <div class="form-box">
    <h3>Crear Noticia</h3>
    <form method="POST" action="panel.php" enctype="multipart/form-data">
      <div class="form-group">
        <label>Título</label>
        <input type="text" name="titulo" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Contenido</label>
        <textarea name="contenido" class="form-control" required></textarea>
      </div>
      <div class="form-group">
        <label>Subir Imagen</label>
        <input type="file" name="imagen" class="form-control">
      </div>
      <div class="checkbox">
        <label><input type="checkbox" name="es_urgente"> Es urgente</label>
      </div>
      <button type="submit" name="crear_noticia" class="btn btn-success">Crear Noticia</button>
      <button type="button" class="btn btn-info btn-visualizar" id="btnVerNoticias">Visualizar Noticias</button>
    </form>

    <div class="visualizar-box" id="listaNoticias">
      <h4>Lista de Noticias</h4>
      <ul>
        <?php while ($n = $noticias->fetch_assoc()): ?>
          <li>
            <?= htmlspecialchars($n['titulo']) ?> - <?= htmlspecialchars($n['fecha']) ?>
            <?php if (!empty($n['imagen'])): ?>
              <br><img src="<?= $n['imagen'] ?>" width="120" style="margin-top:5px;border-radius:8px;">
            <?php endif; ?>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>

</div>

<script>
  $("#btnVerEventos").click(() => $("#listaEventos").slideToggle());
  $("#btnVerNoticias").click(() => $("#listaNoticias").slideToggle());
</script>

</body>
</html>

<?php $conn->close(); ?>



