 $(document).ready(function () {
    // 1️⃣ LEER LOS DATOS DEL SCRIPT (SIN CAMBIOS)
    const eventsDataElement = document.getElementById('events-data');
    let events = [];

    if (eventsDataElement) {
        try {
            events = JSON.parse(eventsDataElement.textContent);
            console.log("✅ Eventos cargados correctamente:", events);
        } catch (e) {
            console.error("❌ Error al parsear el JSON de eventos:", e);
        }
    }

    // 2️⃣ ABRIR EL MODAL CON DETALLES (SIN CAMBIOS)
    $('.details-btn').on('click', function () {
        const eventId = parseInt($(this).data('event-id'));
        const event = events.find(e => e.id === eventId);

        if (event) {
            $('#modalTitle').text(event.title);
            $('#modalImage').attr('src', event.image);
            $('#modalDescription').text(event.description);
            $('#modalDate').text(event.event_date);
            $('#modalTime').text(event.event_time);
            $('#modalCategory').text(event.category);
            $('#modalTags').text(event.etiquetas);
            $('#detalleIdEvento').val(event.id); // 👈 Guarda el ID para inscribirse

            $('#eventDetailsModal').modal('show');
        } else {
            alert('❌ No se pudo encontrar la información del evento.');
        }
    });

    // --- NUEVO: LÓGICA PARA EL CORAZÓN DE FAVORITOS ---
    $('.favorite-heart').on('click', function(e) {
        e.stopPropagation(); // Evita que se active el clic en la tarjeta

        const heart = $(this);
        const eventoId = heart.data('event-id');
        const usuarioId = $('#usuario_id').val();

        // Verificar si el usuario está logueado ANTES de la petición
        if (!usuarioId) {
            alert('⚠️ Debes iniciar sesión para gestionar tus favoritos.');
            return;
        }

        // Determinar la acción (add o remove) basándose en la clase actual
        const isCurrentlyFavorite = heart.hasClass('is-favorite');
        const action = isCurrentlyFavorite ? 'remove' : 'add';

        // Animación y feedback visual inmediato
        heart.toggleClass('is-favorite');

        // Petición AJAX para gestionar el favorito
        $.ajax({
            url: 'toggle_favorito.php',
            method: 'POST',
            data: {
                usuario_id: usuarioId,
                evento_id: eventoId,
                action: action
            },
            dataType: 'json', // Le decimos a jQuery que espere un JSON
            success: function(response) {
                // Este bloque se ejecuta si la petición fue exitosa (HTTP 200)
                if (response.status === 'ok') {
                    // Actualizar el título (tooltip) del corazón
                    const newTitle = action === 'add' ? 'Quitar de favoritos' : 'Añadir a favoritos';
                    heart.attr('title', newTitle);
                    // Mostrar mensaje de éxito
                    alert(response.message);
                } else {
                    // Si el servidor devolvió un error (status: 'error')
                    // Revertimos el cambio visual y mostramos el mensaje de error
                    heart.toggleClass('is-favorite');
                    alert(response.message || 'Ocurrió un error inesperado.');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                // Este bloque se ejecuta si la petición falló (ej. error 500, 404, etc.)
                console.error("Error en AJAX:", textStatus, errorThrown);
                // Revertimos el cambio visual
                heart.toggleClass('is-favorite');
                alert('❌ No se pudo conectar con el servidor. Inténtalo de nuevo.');
            }
        });
    });

    // 3️⃣ CUANDO HACE CLIC EN “INSCRIBIRSE” (MEJORADO)
    // Se usa $(document).on('click', ...) para asegurar que funcione incluso si el modal se carga dinámicamente
    $(document).on('click', '#btnInscribirse', function () {
        const usuarioIdEl = document.getElementById('usuario_id');
        const usuarioId = usuarioIdEl ? usuarioIdEl.value.trim() : '';
        const eventoId = document.getElementById('detalleIdEvento').value;

        if (!eventoId) {
            alert('⚠️ No se pudo obtener el ID del evento.');
            return;
        }

        if (!usuarioId) {
            alert('⚠️ Por favor, inicia sesión antes de inscribirte.');
            return;
        }

        // 4️⃣ Enviar la inscripción al servidor (MEJORADO con $.ajax)
        $.ajax({
            url: 'inscribirse_evento.php',
            method: 'POST',
            data: {
                usuario_id: usuarioId,
                evento_id: eventoId
            },
            dataType: 'json',
            success: function(data) {
                if (data.status === 'ok') {
                    alert('✅ Te has inscrito correctamente al evento.');
                    $('#eventDetailsModal').modal('hide');
                } else if (data.status === 'exists') {
                    alert('⚠️ Ya estás inscrito en este evento.');
                } else {
                    alert('❌ Ocurrió un error al inscribirte: ' + (data.message || 'Error desconocido.'));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('Error en la inscripción:', textStatus, errorThrown);
                alert('❌ No se pudo conectar con el servidor.');
            }
        });
    });
});
