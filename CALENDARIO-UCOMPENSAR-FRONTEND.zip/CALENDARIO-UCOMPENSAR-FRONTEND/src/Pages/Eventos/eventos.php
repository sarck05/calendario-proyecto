<?php
// Iniciar sesión de forma robusta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/../../config/conexion.php');

// --- OBTENER LOS FAVORITOS DEL USUARIO LOGUEADO ---
 $user_favorites_ids = [];
if (isset($_SESSION['usuario_id'])) {
    $usuario_id = $_SESSION['usuario_id'];
    $sql_fav = "SELECT id_evento FROM favoritos WHERE id_usuario = ?";
    $stmt_fav = $conn->prepare($sql_fav);
    $stmt_fav->bind_param("i", $usuario_id);
    $stmt_fav->execute();
    $result_fav = $stmt_fav->get_result();
    while ($row = $result_fav->fetch_assoc()) {
        $user_favorites_ids[] = $row['id_evento'];
    }
}

// --- OBTENER TODOS LOS EVENTOS ---
 $sql = "SELECT
            e.id, e.nombre, e.descripcion, e.tipo, e.fecha, e.imagen,
            GROUP_CONCAT(et.nombre SEPARATOR ', ') AS etiquetas
        FROM eventos e
        LEFT JOIN evento_etiquetas ee ON e.id = ee.evento_id
        LEFT JOIN etiquetas et ON ee.etiqueta_id = et.id
        GROUP BY e.id
        ORDER BY e.fecha ASC";
 $result = $conn->query($sql);

 $events_data = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $timestamp = strtotime($row['fecha']);
        $events_data[] = [
            'id' => (int)$row['id'],
            'title' => $row['nombre'],
            'description' => $row['descripcion'],
            'event_date' => date('Y-m-d', $timestamp),
            'event_time' => date('H:i', $timestamp),
            'category' => $row['tipo'],
            'etiquetas' => $row['etiquetas'] ?: 'Sin etiquetas',
            'image' => $row['imagen']
            ? '../../../public/uploads/' . htmlspecialchars($row['imagen'])
            : "https://picsum.photos/seed/evento{$row['id']}/600/400.jpg",
        ];
    }
}

 $conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos UCompensar</title>
    <!-- Fuentes modernas -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Librerías (Bootstrap 3) -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    
    <!-- Tu CSS mejorado -->
    <link rel="stylesheet" href="../../../public/css/eventos.css">

    <!-- *** CSS para el corazón y el espaciado *** -->
    <style>
        /* Aumentar el espacio entre las tarjetas de eventos */
        #listaEventos > div {
            margin-bottom: 30px;
        }
        .event-card {
            position: relative;
            overflow: hidden;
        }
        .favorite-heart {
            position: absolute;
            bottom: 10px;
            right: 10px;
            font-size: 24px;
            color: rgba(0, 0, 0, 0.5); /* Color con borde por defecto */
            cursor: pointer;
            transition: color 0.2s ease-in-out, transform 0.2s ease-in-out;
            z-index: 10;
            background-color: rgba(255, 255, 255, 0.7);
            border-radius: 50%;
            padding: 5px;
        }
        .favorite-heart.is-favorite {
            color: red; /* Color rojo cuando es favorito */
        }
        .favorite-heart:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body class="Eventos">
    <!-- MENU -->
    <?php include('../../Components/menu.php'); ?>
    <!-- FIN MENU -->

    <!-- Input oculto con el ID del usuario logueado -->
    <?php if (isset($_SESSION['usuario_id'])): ?>
        <input type="hidden" id="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">
    <?php else: ?>
        <input type="hidden" id="usuario_id" value="">
    <?php endif; ?>

    <div class="container mt-5">
        <div class="header text-center mb-4">
            <h1>EVENTOS UCOMPENSAR</h1>
            <p>Descubre los próximos eventos en nuestra universidad</p>
        </div>

        <?php if (empty($events_data)): ?>
            <div class="alert alert-warning text-center">
                <h4>No hay eventos disponibles en este momento.</h4>
                <p>Vuelve pronto para conocer nuestras nuevas actividades.</p>
            </div>
        <?php else: ?>
            <div class="row" id="listaEventos">
                <?php foreach ($events_data as $ev): ?>
                    <div class="col-md-4 mb-4">
                        <div class="event-card shadow-sm">
                            <img src="<?php echo $ev['image']; ?>" class="event-image" alt="<?php echo $ev['title']; ?>">
                            <div class="event-body">
                                <div class="event-category"><?php echo htmlspecialchars($ev['category']); ?></div>
                                <h5 class="event-title"><?php echo htmlspecialchars($ev['title']); ?></h5>
                                <p class="event-description"><?php echo htmlspecialchars($ev['description']); ?></p>
                                <div class="event-meta">
                                    <span><i class="bi bi-calendar-event"></i> <?php echo $ev['event_date']; ?></span>
                                    <span><i class="bi bi-clock"></i> <?php echo $ev['event_time']; ?></span>
                                </div>
                                <button class="btn btn-primary details-btn w-100" data-event-id="<?php echo $ev['id']; ?>">Ver Detalles</button>
                            </div>
                            <!-- *** CORAZÓN DE FAVORITOS *** -->
                            <?php
                                // Comprobar si el evento actual está en la lista de favoritos del usuario
                                $is_favorite = in_array($ev['id'], $user_favorites_ids);
                                $heart_class = $is_favorite ? 'bi-heart-fill is-favorite' : 'bi-heart-fill';
                            ?>
                            <i class="bi <?php echo $heart_class; ?> favorite-heart" 
                               data-event-id="<?php echo $ev['id']; ?>"
                               title="<?php echo $is_favorite ? 'Quitar de favoritos' : 'Añadir a favoritos'; ?>"></i>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal Mejorado -->
    <div class="modal fade" id="eventDetailsModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">Título del Evento</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="modal-image-container">
                                <img id="modalImage" src="" class="img-fluid rounded shadow-sm" alt="Imagen del evento">
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="modal-details-container">
                                <p id="modalDescription">Descripción...</p>
                                <div class="modal-meta">
                                    <p><i class="bi bi-calendar-event"></i> <strong>Fecha:</strong> <span id="modalDate">--</span></p>
                                    <p><i class="bi bi-clock"></i> <strong>Hora:</strong> <span id="modalTime">--</span></p>
                                    <p><i class="bi bi-tag"></i> <strong>Categoría:</strong> <span id="modalCategory">--</span></p>
                                    <p><i class="bi bi-tags"></i> <strong>Etiquetas:</strong> <span id="modalTags">--</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="detalleIdEvento" name="detalleIdEvento" value="">
                <div class="modal-footer d-flex justify-content-between">
                    <button id="btnInscribirse" class="btn btn-primary">Inscribirse</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Datos y script -->
    <script id="events-data" type="application/json"><?php echo json_encode($events_data, JSON_UNESCAPED_UNICODE); ?></script>

    <script>
    $(document).ready(function () {
        // --- LÓGICA PARA EL CORAZÓN DE FAVORITOS ---
        $('.favorite-heart').on('click', function(e) {
            e.stopPropagation(); // Evita que se active el clic en la tarjeta

            const heart = $(this);
            const eventoId = heart.data('event-id');
            const usuarioId = $('#usuario_id').val();

            // Verificar si el usuario está logueado ANTES de la petición
            if (!usuarioId) {
                alert('⚠️ Debes iniciar sesión para gestionar tus favoritos.');
                return;
            }

            // Determinar la acción (add o remove) basándose en la clase actual
            const isCurrentlyFavorite = heart.hasClass('is-favorite');
            const action = isCurrentlyFavorite ? 'remove' : 'add';

            // Animación y feedback visual inmediato
            heart.toggleClass('is-favorite');

            // Petición AJAX para gestionar el favorito
            $.ajax({
                url: 'toggle_favorito.php',
                method: 'POST',
                data: {
                    usuario_id: usuarioId,
                    evento_id: eventoId,
                    action: action
                },
                dataType: 'json', // Le decimos a jQuery que espere un JSON
                success: function(response) {
                    // Este bloque se ejecuta si la petición fue exitosa (HTTP 200)
                    if (response.status === 'ok') {
                        // Actualizar el título (tooltip) del corazón
                        const newTitle = action === 'add' ? 'Quitar de favoritos' : 'Añadir a favoritos';
                        heart.attr('title', newTitle);
                        // Mostrar mensaje de éxito
                        alert(response.message);
                    } else {
                        // Si el servidor devolvió un error (status: 'error')
                        // Revertimos el cambio visual y mostramos el mensaje de error
                        heart.toggleClass('is-favorite');
                        alert(response.message || 'Ocurrió un error inesperado.');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    // Este bloque se ejecuta si la petición falló (ej. error 500, 404, etc.)
                    console.error("Error en AJAX:", textStatus, errorThrown);
                    // Revertimos el cambio visual
                    heart.toggleClass('is-favorite');
                    alert('❌ No se pudo conectar con el servidor. Revisa la consola para más detalles.');
                }
            });
        });

        // --- CÓDIGO PARA EL MODAL ---
        const eventsDataElement = document.getElementById('events-data');
        let events = [];
        if (eventsDataElement) {
            try {
                events = JSON.parse(eventsDataElement.textContent);
            } catch (e) {
                console.error("❌ Error al parsear el JSON de eventos:", e);
            }
        }

        $('.details-btn').on('click', function () {
            const eventId = parseInt($(this).data('event-id'));
            const event = events.find(e => e.id === eventId);
            if (event) {
                $('#modalTitle').text(event.title);
                $('#modalImage').attr('src', event.image);
                $('#modalDescription').text(event.description);
                $('#modalDate').text(event.event_date);
                $('#modalTime').text(event.event_time);
                $('#modalCategory').text(event.category);
                $('#modalTags').text(event.etiquetas);
                $('#detalleIdEvento').val(event.id);
                $('#eventDetailsModal').modal('show');
            } else {
                alert('❌ No se pudo encontrar la información del evento.');
            }
        });

        $(document).on('click', '#btnInscribirse', function () {
            const usuarioId = $('#usuario_id').val();
            const eventoId = $('#detalleIdEvento').value;

            if (!eventoId) { alert('⚠️ No se pudo obtener el ID del evento.'); return; }
            if (!usuarioId) { alert('⚠️ Por favor, inicia sesión antes de inscribirte.'); return; }

            $.ajax({
                url: 'inscribirse_evento.php',
                method: 'POST',
                data: { usuario_id: usuarioId, evento_id: eventoId },
                dataType: 'json',
                success: function(data) {
                    if (data.status === 'ok') { alert('✅ Te has inscrito correctamente.'); $('#eventDetailsModal').modal('hide'); }
                    else if (data.status === 'exists') { alert('⚠️ Ya estás inscrito en este evento.'); }
                    else { alert('❌ Ocurrió un error al inscribirte: ' + (data.message || 'Error desconocido.')); }
                },
                error: function() { alert('❌ No se pudo conectar con el servidor.'); }
            });
        });
    });
    </script>
</body>
</html>