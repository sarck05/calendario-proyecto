<?php
session_start();
require_once("../../config/conexion.php");

// --- Verificar sesión activa ---
if (!isset($_SESSION['usuario_id'])) {
    header("Location: /src/Pages/Sesion/login.php");
    exit();
}

// --- Variables para el menú (de tu código) ---
 $logeado = isset($_SESSION['usuario_id']);
 $nombre = $logeado ? $_SESSION['usuario_nombre'] : '';
 $rol = $logeado ? $_SESSION['usuario_rol'] : '';

// --- Obtener datos del usuario en sesión ---
 $idUsuario = $_SESSION['usuario_id'];
 $sql = "SELECT id, nombre, correo, rol FROM usuarios WHERE id = ?";
 $stmt = $conn->prepare($sql);
 $stmt->bind_param("i", $idUsuario);
 $stmt->execute();
 $result = $stmt->get_result();
 $usuario = $result->fetch_assoc();

if (!$usuario) {
    session_destroy();
    header("Location: /src/Pages/Sesion/login.php");
    exit();
}

// --- NUEVA CONSULTA: OBTENER TODA LA INFORMACIÓN DE LOS EVENTOS FAVORITOS ---
 $sqlFav = "
    SELECT
        e.id, e.nombre, e.descripcion, e.tipo, e.fecha, e.hora, e.lugar, e.imagen,
        GROUP_CONCAT(et.nombre SEPARATOR ', ') AS etiquetas
    FROM eventos e
    INNER JOIN favoritos f ON e.id = f.id_evento
    LEFT JOIN evento_etiquetas ee ON e.id = ee.evento_id
    LEFT JOIN etiquetas et ON ee.etiqueta_id = et.id
    WHERE f.id_usuario = ?
    GROUP BY e.id
    ORDER BY e.fecha ASC
";
 $stmtFav = $conn->prepare($sqlFav);
 $stmtFav->bind_param("i", $idUsuario);
 $stmtFav->execute();
 $resultFav = $stmtFav->get_result();

 $fav_events_data = [];
if ($resultFav && $resultFav->num_rows > 0) {
    while ($row = $resultFav->fetch_assoc()) {
        $timestamp = strtotime($row['fecha']);
        $fav_events_data[] = [
            'id' => (int)$row['id'],
            'title' => $row['nombre'],
            'description' => $row['descripcion'],
            'event_date' => date('Y-m-d', $timestamp),
            'event_time' => date('H:i', $timestamp),
            'category' => $row['tipo'],
            'etiquetas' => $row['etiquetas'] ?: 'Sin etiquetas',
            'image' => $row['imagen']
            ? '../../../public/uploads/' . htmlspecialchars($row['imagen'])
            : "https://picsum.photos/seed/evento{$row['id']}/600/400.jpg",
        ];
    }
}

 $conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil - UCompensar</title>
    
    <!-- *** CAMBIO CLAVE: Añadir el CSS del menú que se usará ahora *** -->
    <link rel="stylesheet" href="/public/css/estructura.css">
    
    <!-- CSS de Bootstrap y de la página -->
    <link rel="stylesheet" href="../../../public/css/perfil.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    
    <!-- Bloque de estilos para las tarjetas de favoritos (los estilos del menú han sido eliminados de aquí) -->
    <style>
        /* Estilos para las tarjetas de favoritos (verticales) */
        .favorite-event-card {
            display: flex;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: relative;
            transition: transform 0.2s ease-in-out;
        }
        .favorite-event-card:hover {
            transform: translateY(-3px);
        }
        .favorite-event-card .card-image-container {
            flex: 0 0 250px; /* Ancho fijo para la imagen */
            background-size: cover;
            background-position: center;
        }
        .favorite-event-card .card-content {
            flex: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .favorite-event-card .card-title {
            font-size: 1.25em;
            font-weight: 600;
            margin-top: 0;
        }
        .favorite-event-card .card-meta {
            font-size: 0.9em;
            color: #555;
        }
        .favorite-event-card .card-meta i {
            margin-right: 5px;
        }
        /* Corazón para quitar de favoritos */
        .remove-favorite-heart {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 24px;
            color: red;
            cursor: pointer;
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 50%;
            padding: 5px;
            transition: transform 0.2s ease-in-out, color 0.2s;
        }
        .remove-favorite-heart:hover {
            transform: scale(1.2);
            color: darkred;
        }
    </style>
</head>

<body>
    <!-- *** CAMBIO CLAVE: Menú integrado directamente, eliminando el include *** -->
    <div class="Menu">
      <div class="container-fluid menu-container">
        <div class="row menu-row">
          <!-- LOGO -->
          <div class="col-md-3 menu-logo">
            <img src="/public/img/logo-compensar.png" alt="Logo Compensar" class="img-responsive">
          </div>

          <!-- MENÚ PRINCIPAL -->
          <div class="col-md-6">
            <ul class="nav navbar-nav menu-principal">
              <li><a href="/index.php">Inicio</a></li>
              <li><a href="/src/Pages/Calendario/calendario.php">Calendario</a></li>
              <li><a href="/src/Pages/Eventos/eventos.php">Eventos</a></li>
              <li><a href="/src/Pages/Noticias/noticias.php">Noticias</a></li>
              <li><a href="/src/Pages/Sesion/Contacto.php">Contáctanos</a></li>
            </ul>
          </div>

          <!-- SESIÓN DE USUARIO -->
          <div class="col-md-3" style="margin-right: 20px;">
            <ul class="nav navbar-nav navbar-right menu-sesion">
              <?php if (!$logeado): ?>
                <!-- Usuario no logueado -->
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="bi bi-person-fill-down"></i> Iniciar Sesión <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu">
                    <li><a href="/src/Pages/Sesion/login.php"><i class="bi bi-person-fill"></i> Login</a></li>
                    <li><a href="/src/Pages/Sesion/register.php"><i class="bi bi-person-fill-add"></i> Registrarse</a></li>
                  </ul>
                </li>
              <?php else: ?>
                <!-- Usuario logueado -->
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="bi bi-person-fill"></i> <?= htmlspecialchars($nombre) ?> <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu">
                    <?php if($rol === 'admin'): ?>
                      <li><a href="/src/Pages/Panel/panel.php"><i class="bi bi-speedometer2"></i> Panel Central</a></li>
                    <?php endif; ?>
                    <li><a href="/src/Pages/Sesion/perfil.php"><i class="bi bi-person"></i> Perfil</a></li>
                    <li><a href="/src/Pages/Sesion/logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar Sesión</a></li>
                  </ul>
                </li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="container" style="margin-top: 30px;">
        <h2>Perfil del Usuario</h2>
        <hr>
        <div class="panel panel-default">
            <div class="panel-heading"><b>Información Personal</b></div>
            <div class="panel-body">
                <p><strong>Nombre:</strong> <?= htmlspecialchars($usuario['nombre']) ?></p>
                <p><strong>Correo:</strong> <?= htmlspecialchars($usuario['correo']) ?></p>
                <p><strong>Rol:</strong> <?= htmlspecialchars($usuario['rol']) ?></p>
            </div>
        </div>

        <!-- SECCIÓN: TUS EVENTOS FAVORITOS CON DISEÑO DE TARJETA -->
        <div class="panel panel-default">
            <div class="panel-heading"><b>Mis Eventos Favoritos</b></div>
            <div class="panel-body">
                <?php if (empty($fav_events_data)): ?>
                    <p>No tienes eventos favoritos registrados. Ve a la página de <a href="/src/Pages/Eventos/eventos.php">Eventos</a> para añadir algunos.</p>
                <?php else: ?>
                    <div id="listaFavoritos">
                        <?php foreach ($fav_events_data as $ev): ?>
                            <div class="favorite-event-card" data-event-id="<?php echo $ev['id']; ?>">
                                <div class="card-image-container" style="background-image: url('<?php echo $ev['image']; ?>');"></div>
                                <div class="card-content">
                                    <div>
                                        <h5 class="card-title"><?php echo htmlspecialchars($ev['title']); ?></h5>
                                        <p><?php echo htmlspecialchars($ev['description']); ?></p>
                                        <div class="card-meta">
                                            <span><i class="bi bi-calendar-event"></i> <?php echo $ev['event_date']; ?></span>
                                            <span><i class="bi bi-clock"></i> <?php echo $ev['event_time']; ?></span>
                                            <span><i class="bi bi-tag"></i> <?php echo htmlspecialchars($ev['category']); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <!-- Corazón para quitar de favoritos -->
                                <i class="bi bi-heart-fill remove-favorite-heart" 
                                   data-event-id="<?php echo $ev['id']; ?>"
                                   title="Quitar de favoritos"></i>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <input type="hidden" id="usuario_id" value="<?php echo $_SESSION['usuario_id']; ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <script>
    $(document).ready(function () {
        // --- LÓGICA PARA QUITAR DE FAVORITOS ---
        $('.remove-favorite-heart').on('click', function(e) {
            e.stopPropagation();
            const heart = $(this);
            const card = heart.closest('.favorite-event-card');
            const eventoId = heart.data('event-id');
            const usuarioId = $('#usuario_id').val();

            if (!usuarioId) {
                alert('⚠️ Debes iniciar sesión para gestionar tus favoritos.');
                return;
            }

            if (!confirm('¿Estás seguro de que quieres quitar este evento de tus favoritos?')) {
                return;
            }

            $.ajax({
                url: 'toggle_favorito.php',
                method: 'POST',
                data: {
                    usuario_id: usuarioId,
                    evento_id: eventoId,
                    action: 'remove' // Acción para quitar
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'ok') {
                        alert(response.message);
                        // Animación para eliminar la tarjeta
                        card.slideUp(400, function() {
                            $(this).remove();
                            // Si no quedan más tarjetas, mostramos el mensaje de "no hay favoritos"
                            if ($('#listaFavoritos .favorite-event-card').length === 0) {
                                location.reload(); // Recargamos para mostrar el mensaje de vacío
                            }
                        });
                    } else {
                        alert('❌ ' + (response.message || 'Ocurrió un error inesperado.'));
                    }
                },
                error: function() {
                    alert('❌ No se pudo conectar con el servidor.');
                }
            });
        });
    });
    </script>
</body>
</html>


